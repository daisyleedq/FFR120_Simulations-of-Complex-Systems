function area = RemoveFires( area )
  area(area==2) = 0;
end

